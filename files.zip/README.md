# Calvin Joy Tarigan — Portfolio

Personal portfolio website deployed via GitHub Pages.

**Live:** https://cjoyy.github.io

## Structure

```
.
├── index.html          # Home
├── projects.html       # Projects
├── experience.html     # Experience, Education, Certs, Skills
├── contact.html        # Contact links
└── assets/
    ├── style.css       # All styles
    └── main.js         # Interactions
```

## Deploy to GitHub Pages

1. Create a new repo named `cjoyy.github.io` on GitHub
2. Clone it locally:
   ```bash
   git clone https://github.com/cjoyy/cjoyy.github.io
   ```
3. Copy all files into the repo folder
4. Push to `main` branch:
   ```bash
   git add .
   git commit -m "initial portfolio"
   git push origin main
   ```
5. Go to **Settings → Pages → Branch: main → / (root)** → Save
6. Your site will be live at `https://cjoyy.github.io` within a minute or two.

## No build step needed — pure HTML/CSS/JS.
